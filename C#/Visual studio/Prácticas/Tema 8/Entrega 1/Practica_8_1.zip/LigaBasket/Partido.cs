﻿// Clase Partido
class Partido
{
    Equipo equipo1;
    Equipo equipo2;
    int puntosequipo1;
    int puntosequipo2;

    public Equipo Equipo1
    {
        get { return equipo1; }
        set { equipo1 = value; }
    }

    public Equipo Equipo2
    {
        get { return equipo2; }
        set { equipo2 = value; }
    }

    public int Puntosequipo1
    {
        get { return puntosequipo1; }
        set { puntosequipo1 = value; }
    }

    public int Puntosequipo2
    {
        get { return puntosequipo2; }
        set { puntosequipo1 = value; }
    }
}
